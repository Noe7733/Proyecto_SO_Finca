
const express = require('express');
const cors = require('cors');

const app = express();

// Habilita CORS para todas las rutas
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: false}))


//Importar, para Definir las rutas
app.use(require('./routes/rutas'))

app.listen(3000);
console.log('Server on port 3000');