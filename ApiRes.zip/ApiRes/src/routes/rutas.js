const { Router } = require('express');
const router = Router();

const { getTerreno, postTerreno, getTerrenoById, deleteTerreno, updateTerreno, postLoteCafe, deleteLoteCafe, putLoteCafe, getLoteCafeById, getLotesCafe, 
    postRecoleccion, llenarTablaRecoleccion, putRecolecion, actStsRec, getDespulpado, getDataDespulpado, actDespulpado, actStsDespulpado, insertTanques, 
    updateTanques, deleteTanques, getTanques, postCargaFermenta, getFermentacion, putFermentacion, getTanquesSts, putFinishFermentacion, cargarLoteLavado, 
    getLavado, registarActualizarLavado, insertCuartos, getCuartos, deleteCuartos, postCargaSecado, getSecado, getCuartosSts, putSecado, putFinishSecado,
    reporte1, reporte2, reporte3, reporte4, reporte5, reporte6, getLotesCafee, InsertUsuarios, ValidateUsuario } = require('../controllers/controllers');

//rutas para el crud de la tabla terreno
router.get('/terreno', getTerreno);
router.get('/terreno/:id', getTerrenoById);
router.post('/CreateTerreno', postTerreno);
router.delete('/DeleteTerreno/:id', deleteTerreno);
router.put('/updateTerreno/:id', updateTerreno);
//rutas para el crud de la tabla terreno
router.get('/obtLoteCafe/:id', getLoteCafeById);
router.get('/obtLotesCafe', getLotesCafe);
router.post('/CreateLoteCafe', postLoteCafe);
router.delete('/borrarLoteCafe/:id', deleteLoteCafe);
router.put('/actLoteCafe/:id', putLoteCafe);
//rutas para el crud de la tabla recolecion
router.post('/createAllRecolection', postRecoleccion);
router.get('/tablaPrincRecolec', llenarTablaRecoleccion);
router.put('/actStsTrash/:id', actStsRec);
router.post('/actCantCafe', putRecolecion);
//despulpado
router.post('/tablaPrincDespul', getDespulpado);
router.get('/selectDataDespul', getDataDespulpado);
router.post('/fechaHoraDespulpado', actDespulpado);
router.put('/actStsDespul/:id', actStsDespulpado);
//tanques
router.post('/postTanque', insertTanques);
router.get('/getTanques', getTanques);
router.put('/putTanque/:id', updateTanques);
router.delete('/deleteTanque/:id', deleteTanques);
//Fermentacion
router.post('/AllPostFermentacion', postCargaFermenta);
router.get('/getFermentacion', getFermentacion);
router.post('/updateRegistroFer', putFermentacion);
router.get('/selectStsTanques', getTanquesSts);
router.post('/finishFermentacion', putFinishFermentacion);
//Lavado
router.post('/CargarLotesLavado', cargarLoteLavado);
router.get('/ListarDatosLavado', getLavado);
router.post('/RegistroActualizarLavado', registarActualizarLavado)

//Cuartos de secado
router.post('/InsertCuartos', insertCuartos);
router.get('/listarCuartos', getCuartos);
router.delete('/deleteCuarto', deleteCuartos)
//Tabla de secado
router.post('/cargaLotesSecado', postCargaSecado);
router.get('/ListarDatosSecado', getSecado);
router.post('/InicioRegistroSecado', putSecado);
router.post('/finalizarRegistroSecado', putFinishSecado);
router.get('/selectStsCuartos', getCuartosSts);

//agregadas

router.post('/reporteUno', reporte1);
router.get('/reporteDos', reporte2);
router.get('/reporteTres', reporte3);
router.get('/reporteCuatro', reporte4);
router.get('/reporteCinco', reporte5);
router.get('/reporteSeis', reporte6);

router.get('/getLotes', getLotesCafee);

//insertar usuario con sha-256
router.post('/InsertarUsuario', InsertUsuarios);
router.post('/ValidaUser', ValidateUsuario);
module.exports = router;