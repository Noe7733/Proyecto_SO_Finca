//conexion a la -BD
const { Pool } = require('pg');
const moment = require('moment');
const crypto = require('crypto');


const pool = new Pool({
    host: 'database-cafe.ccuwublznyky.us-east-1.rds.amazonaws.com',
    user: 'root',
    password: 'admin2023',
    database: 'fincacafe',
    port: '5432',
    ssl: {
        rejectUnauthorized: false, // En entornos de producción, deberías configurar esto correctamente
    },
});

const client = pool.connect();
console.log("respuesta cliente: ", client);
//tabla terrenos

const getTerreno = async (req, res) => {
    const response = await pool.query('SELECT * FROM terreno ORDER BY numterreno ASC');
    res.status(200).json(response.rows);
    console.log(response.rows);
};

const getTerrenoById = async (req, res) => {
    const numterreno = req.params.id;
    const responde = await pool.query('SELECT * FROM terreno WHERE numterreno = $1', [numterreno])
    res.json(responde.rows);
};

const postTerreno = async (req, res) => {
    const { nombret } = req.body;
    const response = await pool.query('INSERT INTO terreno (nombret) VALUES ($1)', [nombret]);
    console.log(response);
    res.send('Terreno creado con exito');
};

const deleteTerreno = async (req, res) => {
    const numterreno = req.params.id;
    const response = await pool.query('DELETE FROM terreno WHERE numterreno = $1', [numterreno]);
    console.log(response);
    res.json('terreno eliminado exitosamente');
};

const updateTerreno = async (req, res) => {
    const numterreno = req.params.id;
    const { nombret } = req.body;
    const response = await pool.query('UPDATE terreno SET nombret = $1 WHERE numterreno = $2', [
        nombret,
        numterreno
    ]);
    console.log(response);
    res.json('terreno actualizado correctamente');
};

//tabla lotes

const getLotesCafe = async (req, res) => {
    const response = await pool.query('SELECT * FROM lotecafe ORDER BY numlote ASC');
    res.status(200).json(response.rows);
    console.log(response.rows);
};

const getLoteCafeById = async (req, res) => {
    const numlote = req.params.id;
    const response = await pool.query('SELECT * FROM lotecafe WHERE numlote = $1', [numlote]);
    res.json(response.rows);
};

const postLoteCafe = async (req, res) => {
    const { tipograno } = req.body;
    const { numterreno } = req.body;
    const response = await pool.query('INSERT INTO lotecafe (tipograno, numterreno) VALUES ($1, $2)', [tipograno, numterreno]);
    res.status(200).send({ message: 'Éxito' });
};

const putLoteCafe = async (req, res) => {
    const numlote = req.params.id;
    const numterreno = parseInt(req.body.nlte);
    const tipograno = req.body.nombret;
    const response = await pool.query('UPDATE lotecafe SET tipograno = $1, numterreno = $2 WHERE numlote = $3', [
        tipograno,
        numterreno,
        numlote,
    ]);
    console.log("chela pq :", response);
    res.json('terreno actualizado correctamente');
};

const deleteLoteCafe = async (req, res) => {
    const numlote = req.params.id;
    const response = await pool.query('DELETE FROM lotecafe WHERE numlote = $1', [numlote]);
    console.log(response);
    res.json('terreno eliminado exitosamente');
};

const postRecoleccion = async (req, res) => {
    const response = await pool.query('CALL crearRecoleccion()');
    console.log(response);
    res.json(' Lotes ingresados correctamente');
};

const llenarTablaRecoleccion = async (req, res) => {
    try {
        const response = await pool.query('SELECT * FROM crearRecoleccion;');
        
        // Iterar a través de cada registro y formatear la fecha
        response.rows.forEach((row) => {
            if(row.fec){
                row.fec = moment(row.fec).format('DD/MM/YYYY');
                // moment(fecha).format('YYYY-MM-DD');
            } else {
                row.fec ='NO RECOLECTADO';
            }
            
        });

        console.log('FECHA DATE: ', response.rows[0].fec);
        console.log('llenar tabla R: ', response.rows);

        res.json(response.rows);
    } catch (error) {
        console.error('Error al llenar la tabla de recolección:', error);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
};
const putRecolecion = async (req, res) => {
    const id = req.body.id;
    const lte = req.body.lte;
    const cla_1 = req.body.cant1;
    const cla_2 = req.body.cant2;
    const cla_3 = req.body.cant3;
    const cla_4 = req.body.cant4;
    const response = await pool.query('CALL actualizarclasificacion($1, $2, $3, $4, $5, $6, null)', [
        id,
        lte,
        cla_1,
        cla_2,
        cla_3,
        cla_4,
    ]);
    console.log("Este mensajes es despues de hacer el response ");
    res.status(200).send({ message: 'Éxito' });
};

const actStsRec = async (req, res) => {
    const id = req.params.id;
    const sts = 'TRUNCADO';
    console.log(id);
    const response = await pool.query('UPDATE recoleccion SET statusr = $1  where idrecoleccion = $2', [
        sts,
        id,
    ]);
    console.log("chela pq :", response);
    res.json('trunkkk');
}

//tabla despulpado 

const getDespulpado = async (req, res) => {
    const response = await pool.query('CALL crearDespulpado()');
    res.json(response.rows);
    console.log('llenar tabla D: ', response.rows);
}

const getDataDespulpado = async (req, res) => {
    const response = await pool.query('select * from despulpado');

    // console.log(response.rows);
    // Iterar a través de cada registro y formatear la fecha
    response.rows.forEach((row) => {
        // console.log('dentro de for');
        // console.log(row.fecha);
        if (row.fecha) {
            console.log(row.fecha);
            row.fecha = moment(row.fecha).format('DD/MM/YYYY');
            // moment(fecha).format('YYYY-MM-DD');
        }
    });
    console.log('devolucion de la api: ', response.rows);
    res.status(200).json(response.rows);
}

const actDespulpado = async (req, res) => {
    const idD = req.body.iddespulpado;
    const idR = req.body.idrecoleccion;
    const response = await pool.query('CALL actualizardespulpado($1, $2, null)', [
        idD,
        idR,
    ]);
    console.log("Este mensajes es despues de hacer el response ");
    res.status(200).send({ message: 'Éxito' });
}

const actStsDespulpado = async(req, res) => {
    const id = req.params.id;
    const sts = 'TRUNCADO';
    console.log(id);
    const response = await pool.query('UPDATE despulpado SET statusd = $1  where iddespulpado = $2', [
        sts,
        id,
    ]);
    console.log("chela pq :", response);
    res.json('trunkkk');
}
//tabla de tanques

const insertTanques = async (req, res) =>{
    const { maxkgt } = req.body;
    const response = await pool.query('INSERT INTO tanques (maxkgt) VALUES (null)',);
    res.status(200).send({ message: 'Éxito' });
}

const getTanques = async (req, res) =>{
    const response = await pool.query('SELECT * FROM tanques ORDER BY idtanque ASC');
    res.status(200).json(response.rows);
    console.log(response.rows);
}

const updateTanques = async (req, res) =>{
    const idtanque = req.params.id;
    const { numtanque } = req.body;
    const { modelo } = req.body;
    const { maxkgt } = req.body;
    const response = await pool.query('UPDATE tanques SET numtanque = $1, modelo = $2, maxkgt = $3  WHERE idtanque = $4', [
        numtanque,
        modelo,
        maxkgt,
        idtanque,
    ]);
    console.log(response);
    res.json('tanque actualizado correctamente');
}

const deleteTanques = async (req, res) =>{
    const idtanque = req.params.id;
    const response = await pool.query('DELETE FROM tanques WHERE idtanque = $1', [idtanque]);
    console.log(response);
    res.json('tanque eliminado exitosamente');
}

const getTanquesSts = async (req, res)=> {
    const response = await pool.query(" SELECT idtanque AS name, idtanque AS code FROM tanques WHERE statust = 'DISPONIBLE'");
    res.status(200).json(response.rows);
}


//tabla fermentación
const postCargaFermenta = async (req, res) => {
    const response = await pool.query('CALL crearFermentacion()');
    res.json(response.rows);
    console.log('llenar tabla Fermentacion: ', response.rows);
}

const getFermentacion = async (req, res) => {
    const response = await pool.query('select * from fermentacion');
    res.status(200).json(response.rows);
    console.log('Llenado de la tabla fermentacion',response.rows);
}

const putFermentacion = async (req, res) => {
    const {idfermentacion} =req.body;
    const {iddespulpado} = req.body;
    const {idtanque} = req.body;
    const {tempmin} = req.body;
    const {tempmax} = req.body;
    const response = await pool.query('call actualizarFermentacion($1,$2,$3,$4,$5,null)', [
        idfermentacion,
        iddespulpado,
        idtanque,
        tempmin,
        tempmax,
    ]);
    console.log(req.body);
    console.log(response);
    res.json('registro actualizado correctamente');
}

const putFinishFermentacion = async (req, res) =>{
    const {idfermentacion} =req.body;
    const {iddespulpado} = req.body;
    const response = await pool.query('call actualizarfermentacionfinalizacion($1,$2,null)',[
        idfermentacion,
        iddespulpado,
    ]);
    console.log(req.body);
    console.log(response);
    res.json('registro actualizado correctamente');
}

//----------------------------Tabla Lavadooo uwu//////////////
const cargarLoteLavado = async (req, res) => {
    const response = await pool.query('CALL crearLavado()');
    res.json(response.rows);
    console.log('Carga los Lotes de tabla Lavado: ', response.rows);
}

const getLavado = async (req, res) => {
    const response = await pool.query('select * from lavado');
    res.status(200).json(response.rows);
    console.log('Llenado de la tabla lavado',response.rows);
}

//call actualizarLavado(1,1,null);
const registarActualizarLavado = async (req, res) =>{
    const {idlavado} =req.body;
    const {idfermentacion} = req.body;
    const response = await pool.query('CALL actualizarLavado($1,$2,null)', [
        idlavado,
        idfermentacion,
    ]);
    console.log(req.body);
    console.log(response);
    res.json('registro actualizado correctamente');
    console.log('Dato actualizado: ',response.rows);
}

///-------------Apis de Cuartos de secado------------------------
const insertCuartos = async (req, res) =>{
    const { maxkgc } = req.body;
    const response = await pool.query('INSERT INTO cuartos (maxkgc) VALUES (null)',);
    res.status(200).send({ message: 'Éxito' });
}
//
//SELECT * FROM cuartos ORDER BY idcuarto ASC
const getCuartos = async (req, res) =>{
    const response = await pool.query('SELECT * FROM cuartos');
    res.status(200).json(response.rows);
    console.log(response.rows);
}

const deleteCuartos = async (req, res) => {
    const idcuarto = req.params.id;
    try {
        const response = await pool.query("DELETE FROM cuartos WHERE idcuarto = $1", [idcuarto]);
        console.log(response);
        res.json('tanque eliminado exitosamente');
    } catch (error) {
        console.error('Error al eliminar el tanque:', error);
        res.status(500).json('Error al eliminar el tanque');
    }
}

/////-----------------TABLA  DE SECADO UWU-------------------------------
const postCargaSecado = async (req, res) => {
    const response = await pool.query('CALL crearSecado()');
    res.json(response.rows);
    console.log('Cargar lotes a la tabla secado: ', response.rows);
}

const getSecado = async (req, res) => {
    const response = await pool.query('select * from secado');
    res.status(200).json(response.rows);
    console.log('Llenado de la tabla secado: ',response.rows);
}

//
//  call actualizarSecado(1,1,1,'RAPIDO',null); -
const putSecado = async (req, res) => {
    const {idsecado} =req.body;
    const {idlavado} = req.body;
    const {idcuarto} = req.body;
    const {tiposecado} = req.body;
    const response = await pool.query('call actualizarSecado($1,$2,$3,$4,null)', [
        idsecado,
        idlavado,
        idcuarto,
        tiposecado,
    ]);
    console.log('Datos que llegan para actualizar: ',response.rows);
    console.log(req.body);
    console.log(response);
    res.json('se inicio el peoceso de secado');
}

const putFinishSecado = async (req, res) =>{
    const {idsecado} =req.body;
    const {idlavado} = req.body;
    const response = await pool.query('call actualizarSecadoFinalizacion($1,$2,null)',[
        idsecado,
        idlavado,
    ]);
    console.log(req.body);
    console.log(response);
    res.json('se finalizo con exito el secado');
}
const getCuartosSts = async (req, res)=> {
    const response = await pool.query(" SELECT idcuarto AS name, idcuarto AS code FROM cuartos WHERE estado = 'DISPONIBLE'");
    res.status(200).json(response.rows);
}

//------
//consumir metodos para realizar los reportes 

const reporte1 = async (req, res) =>{
    const {numlote} = req.body;
    const response = await pool.query('SELECT * FROM  verprocesolotes($1)',[numlote]);
    res.status(200).json(response.rows);
    console.log('entro respuesta api :', response.rows);
}

const reporte2 = async (req, res) => {
    const response = await pool.query('select * from vistaProcesoLote');
    res.status(200).json(response.rows);
    console.log('entro respuesta:', response.rows);
}

const reporte3 = async (req, res) =>{
    const response = await pool.query('SELECT * FROM TanquesCuartosDisponibles');
    res.status(200).json(response.rows);
    console.log('entro respuesta:', response.rows);
}

const reporte4 = async (req, res) =>{
    const response = await pool.query('select * from vistaRecolecciondemes');
    res.status(200).json(response.rows);
    console.log('entro respuesta:', response.rows);
}

const reporte5 = async (req, res) =>{
    const response = await pool.query('select *from vistaTipoMayorAnioRec');
    res.status(200).json(response.rows);
    console.log('entro respuesta:', response.rows);
}

const reporte6 = async (req, res) =>{
    const response = await pool.query('select *from vistaPromedioTiempoSecado');
    res.status(200).json(response.rows);
    console.log('entro respuesta reporte 6:', response.rows);
}


const getLotesCafee = async (req, res) => {
    const response = await pool.query('SELECT * FROM lotecafe');
    res.status(200).json(response.rows);
    console.log(response.rows);
};


///////////////////////////Usuarios-----------------
const InsertUsuarios = async (req, res) => {
    const { nombreusu, contrausu, nombrec } = req.body;
    // Encriptar la contraseña utilizando SHA-256
    const hashedPassword = crypto.createHash('sha256').update(contrausu).digest('hex');

    const response = await pool.query('INSERT INTO Usuarios (nombreusu, contrausu, nombrec) VALUES ($1, $2, $3)', [
        nombreusu,
        hashedPassword, // Contraseña encriptada con SHA-256
        nombrec,
    ]);
    console.log('Datos que llegan para insertar: ', req.body);
    console.log('Respuesta de la inserción: ', response);
    res.json('Se insertó con éxito');
}

const ValidateUsuario = async (req, res) => {
    const { nombreusu, contrausu } = req.body;
    if (!contrausu || contrausu.trim() === '') {
        return res.status(400).json('La contraseña no puede estar vacía');
    }
    const hashedPassword = crypto.createHash('sha256').update(contrausu).digest('hex');

    try {
        // Buscar el usuario en la base de datos por nombre de usuario
        const user = await pool.query('SELECT * FROM Usuarios WHERE nombreusu = $1', [nombreusu]);

        if (user.rows.length === 0) {
            // Si no se encuentra el usuario, enviar un mensaje de error
            return res.status(401).json('Nombre de usuario o contraseña incorrectos');
        }

        // Verificar si la contraseña coincide con la contraseña almacenada en la base de datos
        if (user.rows[0].contrausu === hashedPassword) {
            // Contraseña correcta, enviar un mensaje de éxito
            return res.json('Usuario y contraseña válidos');
        } else {
            // Contraseña incorrecta, enviar un mensaje de error
            return res.status(401).json('Nombre de usuario o contraseña incorrectos');
        }
    } catch (error) {
        console.error('Error al validar usuario:', error);
        res.status(500).json('Error interno del servidor');
    }
}

// Ruta para validar usuario y contraseña
//app.post('/validateUsuario', ValidateUsuario);

// const getLotesCafee = async (req, res) => {
//     const response = await pool.query('SELECT * FROM lotecafe');
//     res.status(200).json(response.rows);
//     console.log(response.rows);
// };
//

//este es el modulo por medio del cual se exportan los metodos 
module.exports = {
    getTerreno,
    getTerrenoById,
    postTerreno,
    deleteTerreno,
    updateTerreno,
    getLoteCafeById,
    getLotesCafe,
    postLoteCafe,
    deleteLoteCafe,
    putLoteCafe,
    postRecoleccion,
    llenarTablaRecoleccion,
    putRecolecion,
    actStsRec,
    getDespulpado,
    getDataDespulpado,
    actDespulpado,
    actStsDespulpado,
    getTanques,
    updateTanques,
    deleteTanques,
    insertTanques,
    postCargaFermenta,
    getFermentacion,
    putFermentacion,
    getTanquesSts,
    putFinishFermentacion,
    cargarLoteLavado,
    getLavado,
    registarActualizarLavado,
    insertCuartos,
    getCuartos,
    deleteCuartos,
    postCargaSecado,
    getSecado,
    getCuartosSts,
    putSecado,
    putFinishSecado,
    reporte1,
    reporte2,
    reporte3,
    reporte4,
    reporte5,
    reporte6,
    getLotesCafee,
    InsertUsuarios,
    ValidateUsuario
}
